import React, { useState } from 'react';

const Contact = () => {
   
    return (
       <div>
  <h1 className='font-bold text-4xl p-5 text-blue-600'>Contact</h1>
       </div>
    );
}

export default Contact;
