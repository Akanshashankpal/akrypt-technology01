import React from 'react';

const About = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>About</h1>
        </div>
    );
}

export default About;
