import React from 'react';

const Blog = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>Blog</h1>
        </div>
    );
}

export default Blog;
