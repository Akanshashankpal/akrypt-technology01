import React from 'react';

const Service = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>Service</h1>
        </div>
    );
}

export default Service;
