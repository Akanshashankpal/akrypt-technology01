import React from 'react';

const Contact = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>Contact</h1>
        </div>
    );
}

export default Contact;
