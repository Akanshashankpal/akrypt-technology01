import React from 'react';

const Home = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>Home</h1>
        </div>
    );
}

export default Home;
