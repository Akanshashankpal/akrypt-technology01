import React from 'react';

const Career = () => {
    return (
        <div>
            <h1 className='text-lg font-bold'>Career</h1>
        </div>
    );
}

export default Career;
