import React from 'react'


import NewNavbar from './NewNavbar'
import Layout from './Layout'

function NewDashboard() {
  return (
    <div>
          <NewNavbar/>
      {/* <Sidebar/> */}
      {/* <Navbar/> */}
      {/* <UserNavbar/> */}
      <Layout/>
  
    </div>
  )
}

export default NewDashboard
