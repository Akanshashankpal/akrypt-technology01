import React from 'react'
// import DashMainPage from './MainDash'
import DashRoute from '../route/Dashroute'


function Layout() {
  return (
    <div className='bg-navBg my-10'>
      <DashRoute/>
    </div>
  )
}

export default Layout
