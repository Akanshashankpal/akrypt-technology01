import React, { useEffect, useState } from 'react';
import { useToast, Modal, ModalOverlay, ModalContent, ModalHeader, ModalBody, ModalCloseButton, Button, ModalFooter, FormControl, FormLabel, Input } from '@chakra-ui/react';
import axios from "../../axios";
import UserLogo from "../../Images/60111.jpg";

const HomePage = () => {
    const toast = useToast();

    const [isAmountModalOpen, setIsAmountModalOpen] = useState(false);
    const [isPenaltyModalOpen, setIsPenaltyModalOpen] = useState(false);
    const [amount, setAmount] = useState("");
    // const [penalty, setPenalty] = useState("");
    const [collected_officer_code, setPin] = useState("");
    const [profile, setProfile] = useState([]);
    const [addPenaltyFlag,setPenalty]=useState(true)

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const response = await axios.get('/users/profile');
                setProfile(response?.data?.result);
            } catch (error) {
                console.error("Error fetching user data", error);
            }
        };

        fetchProfile();
    }, []);

    const openAmountModal = () => {
        setAmount(profile?.active_loan_id?.emi_day || "");
        setIsAmountModalOpen(true);
    };

    const openPenaltyModal = () => {
        setIsPenaltyModalOpen(true);
        // setPenalty(true)
    };

    const handleAmountSubmit = async (e) => {
        e.preventDefault();
        setIsAmountModalOpen(false);
        setIsPenaltyModalOpen(false);

        let obj = { amount, collected_officer_code};

        try {
            const response = await axios.post("/dailyCollections", obj);
            if (response.data) {
                toast({
                    title: "Success! Amount Added successfully",
                    status: "success",
                    duration: 4000,
                    isClosable: true,
                    position: "top",
                });
                window.location.reload();
            }
        } catch (error) {
            toast({
                title: "Something Went Wrong!",
                status: "error",
                duration: 4000,
                isClosable: true,
                position: "top",
            });
        }
    };

    const handlePenaltySubmit = async (e) => {
        e.preventDefault();
        setIsAmountModalOpen(false);
        setIsPenaltyModalOpen(false);
    
        const obj = { collected_officer_code, addPenaltyFlag };
    
        try {
            const response = await axios.post("/dailyCollections", obj);
            if (response.data) {
                toast({
                    title: "Success! Penalty Added successfully",
                    status: "success",
                    duration: 4000,
                    isClosable: true,
                    position: "top",
                });
                window.location.reload();
            }
        } catch (error) {
            toast({
                title: "Something Went Wrong!",
                status: "error",
                duration: 4000,
                isClosable: true,
                position: "top",
            });
        }
    };
    return (
        <div className="h-screen opacity-80 bg-[url('C:\Users\Ravi\OneDrive\Desktop\akrypt-technology01\Unit-4\Week-1\src\Images\rm222batch4-mind-07.jpg')] bg-cover flex flex-col items-center justify-center space-y-6">

            {/* Main Card Section with Glassmorphism */}
            <div className="backdrop-blur-md bg-white/30 h-[70%] w-11/12 md:w-3/4 lg:w-1/2 mt-5 rounded-xl shadow-lg border border-gray-200 p-6">
                <div className="flex flex-col space-y-6 ">
                    <div className='flex flex-col items-center justify-center w-full h-full'>
                        <img src={UserLogo} alt="user" className='w-6/12 h-6/12 rounded-full m-auto' />
                        <p className="mt-6 font-bold text-xl m-auto text-center">{profile?.full_name}</p>
                    </div>

                    <div className='border-gray-300 border-spacing-2'>
                        <div className="text-xl space-y-6 p-6">
                            <p className="flex justify-between text-start"><strong>Date:</strong> {profile?.created_on}</p>
                            <p className="flex justify-between text-start"><strong>Mobile:</strong> {profile?.phone_number}</p>
                            <p className="flex justify-between text-start"><strong>Loan:</strong> ₹{profile?.active_loan_id?.loan_amount}</p>
                            <p className="flex justify-between text-start"><strong>EMI:</strong> ₹{profile?.active_loan_id?.emi_day}</p>
                            <p className="flex justify-between text-start"><strong>Total Paid:</strong> ₹{profile?.active_loan_id?.total_amount}</p>
                            <p className="flex justify-between text-start"><strong>Due:</strong> ₹{profile?.active_loan_id?.total_due_amount}</p>
                            <p className="flex justify-between text-start"><strong>Penalty:</strong> ₹{profile?.active_loan_id?.total_penalty_amount}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Action Buttons */}
            <div className='flex justify-around mx-auto w-full'>
                {/* Add Amount Button */}
                <button onClick={openAmountModal} className='bg-green-500 text-white py-5 mx-4 w-full text-xl rounded-lg'>
                    Add Amount
                </button>

                {/* Add Penalty Button */}
                <button onClick={openPenaltyModal} className='bg-red-500 text-white py-5 mx-4 w-full text-xl rounded-lg'>
                    Add Penalty
                </button>
            </div>

            {/* Modal for Amount Details */}
            <Modal isOpen={isAmountModalOpen} onClose={() => setIsAmountModalOpen(false)}>
                <ModalOverlay />
                <ModalContent margin="auto">
                    <ModalHeader>Add Amount Details</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <FormControl id="amount" isRequired>
                            <FormLabel>Amount</FormLabel>
                            <Input
                                type="number"
                                value={amount}
                                onChange={(e) => setAmount(e.target.value)}
                                placeholder="Enter Amount"
                            />
                        </FormControl>
                        <FormControl id="pin" isRequired>
                            <FormLabel>Officer PIN</FormLabel>
                            <Input
                                type="text"
                                value={collected_officer_code}
                                onChange={(e) => setPin(e.target.value)}
                                placeholder="Enter Officer PIN"
                            />
                        </FormControl>
                    </ModalBody>
                    <ModalFooter display={"flex"} gap={"10px"}>
                        <Button onClick={() => setIsAmountModalOpen(false)} colorScheme="red">
                            Cancel
                        </Button>
                        <Button onClick={handleAmountSubmit} colorScheme="green">
                            OK
                        </Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>

            {/* Modal for Penalty Details */}
            <Modal isOpen={isPenaltyModalOpen} onClose={() => setIsPenaltyModalOpen(false)}>
                <ModalOverlay />
                <ModalContent margin="auto">
                    <ModalHeader>Add Penalty Details </ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                       
                        <FormControl id="pin" isRequired>
                       
                            <FormLabel>Officer PIN</FormLabel>
                            <Input
                                type="text"
                                value={collected_officer_code}
                                onChange={(e) => setPin(e.target.value)}
                                placeholder="Enter Officer PIN"
                            />
                        </FormControl>
                    </ModalBody>
                    <ModalFooter display={"flex"} gap={"10px"}>
                        <Button onClick={() => setIsPenaltyModalOpen(false)} colorScheme="red">
                            Cancel
                        </Button>
                        <Button onClick={handlePenaltySubmit} colorScheme="green">
                            OK
                        </Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </div>
    );
};

export default HomePage;
